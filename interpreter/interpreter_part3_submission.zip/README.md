To run the interpreter, use the interpret function in `interpreter.rkt`

For example, if you had your code in `test.txt` in the same folder as `interpreter.rkt`, call:

    (interpret "test.txt")